
import React, { useState, useEffect, useMemo } from 'react';
import { UserData, AIAnalysis, AppState } from './types';
import { enhanceUserProfile } from './services/geminiService';
import InputField from './components/InputField';
import MultiSelectField from './components/MultiSelectField';
import Button from './components/Button';
import DateInputField from './components/DateInputField';

const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzXoTetkhD8O5zkec_4OAZxe3xGuNGTyb7IQ7WRPXx0rz1WeunkIqmnbCvhdZk32XEj/exec";

const App: React.FC = () => {
  const [formData, setFormData] = useState<Omit<UserData, 'id' | 'timestamp'>>({
    operador: '',
    tipo: [],
    tkt: '',
    localizador: '',
    dataVoo: '',
    bio: ''
  });
  
  const [state, setState] = useState<AppState>(AppState.IDLE);
  const [view, setView] = useState<'OPERATOR' | 'ADMIN'>('OPERATOR');
  const [aiResult, setAiResult] = useState<AIAnalysis | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [registrations, setRegistrations] = useState<UserData[]>([]);
  const [adminAuth, setAdminAuth] = useState(false);
  const [showPassModal, setShowPassModal] = useState(false);
  const [passInput, setPassInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTicket, setSelectedTicket] = useState<UserData | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('smiles_registrations');
    if (saved) {
      try {
        setRegistrations(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar histórico", e);
      }
    }
  }, []);

  const filteredAndSortedRegistrations = useMemo(() => {
    const parseDate = (dStr: string) => {
      if (!dStr) return new Date(8640000000000000);
      const parts = dStr.split('/').map(Number);
      if (parts.length !== 3) return new Date(8640000000000000); 
      const [d, m, y] = parts;
      return new Date(y, m - 1, d);
    };

    let result = [...registrations];

    if (searchTerm) {
      const lowerSearch = searchTerm.toLowerCase();
      result = result.filter(r => 
        r.localizador.toLowerCase().includes(lowerSearch) || 
        r.tkt.toLowerCase().includes(lowerSearch) ||
        r.operador.toLowerCase().includes(lowerSearch)
      );
    }

    return result.sort((a, b) => {
      const dateA = parseDate(a.dataVoo);
      const dateB = parseDate(b.dataVoo);
      return dateA.getTime() - dateB.getTime();
    });
  }, [registrations, searchTerm]);

  const getPriorityInfo = (dateStr: string) => {
    const parts = dateStr.split('/').map(Number);
    if (parts.length !== 3) return { label: 'INVÁLIDO', color: 'bg-gray-400', icon: 'fa-question' };
    
    const [d, m, y] = parts;
    const flightDate = new Date(y, m - 1, d);
    flightDate.setHours(0,0,0,0);
    const today = new Date();
    today.setHours(0,0,0,0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    if (flightDate.getTime() === today.getTime()) return { label: 'CRÍTICO', color: 'bg-red-500', icon: 'fa-fire' };
    if (flightDate.getTime() === tomorrow.getTime()) return { label: 'ALTA', color: 'bg-orange-500', icon: 'fa-bolt' };
    if (flightDate.getTime() < today.getTime()) return { label: 'ATRASADO', color: 'bg-gray-600', icon: 'fa-clock' };
    return { label: 'NORMAL', color: 'bg-blue-500', icon: 'fa-plane' };
  };

  const stats = useMemo(() => ({
    critical: registrations.filter(r => getPriorityInfo(r.dataVoo).label === 'CRÍTICO').length,
    high: registrations.filter(r => getPriorityInfo(r.dataVoo).label === 'ALTA').length,
    normal: registrations.filter(r => getPriorityInfo(r.dataVoo).label === 'NORMAL').length
  }), [registrations]);

  const salvarNaPlanilha = async (userData: UserData, analysis: AIAnalysis) => {
    try {
      await fetch(APPS_SCRIPT_URL, {
        method: "POST",
        mode: 'no-cors', 
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...userData, analysis })
      });
      console.log("Sincronização nuvem realizada.");
    } catch (error) {
      console.error("Erro na sincronização:", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.tipo.length === 0) {
      setErrorMessage('Selecione pelo menos um serviço.');
      return;
    }
    setState(AppState.SUBMITTING);
    try {
      const userData: UserData = {
        ...formData,
        id: crypto.randomUUID(),
        timestamp: Date.now()
      };

      const analysis = await enhanceUserProfile(userData);
      await salvarNaPlanilha(userData, analysis);

      const updated = [userData, ...registrations];
      setRegistrations(updated);
      localStorage.setItem('smiles_registrations', JSON.stringify(updated));

      setAiResult(analysis);
      setState(AppState.SUCCESS);
    } catch (err) {
      setErrorMessage('Erro ao processar atendimento.');
      setState(AppState.ERROR);
    }
  };

  const handleAdminAccess = () => {
    if (view === 'ADMIN') {
      setView('OPERATOR');
      setAdminAuth(false);
      setSelectedTicket(null);
    } else {
      setShowPassModal(true);
    }
  };

  const verifyPassword = () => {
    if (passInput === "jeff123") {
      setAdminAuth(true);
      setShowPassModal(false);
      setView('ADMIN');
      setPassInput('');
    } else {
      alert("Senha incorreta.");
      setPassInput('');
    }
  };

  const resolveTicket = (id: string) => {
    const updated = registrations.filter(r => r.id !== id);
    setRegistrations(updated);
    localStorage.setItem('smiles_registrations', JSON.stringify(updated));
    setSelectedTicket(null);
  };

  const resetForm = () => {
    setFormData({ operador: '', tipo: [], tkt: '', localizador: '', dataVoo: '', bio: '' });
    setAiResult(null);
    setState(AppState.IDLE);
    setView('OPERATOR');
  };

  return (
    <div className="flex min-h-screen bg-[#F4F7F9]">
      <aside className="hidden lg:flex w-64 bg-[#121B33] flex-col fixed h-full z-40 shadow-2xl">
        <div className="p-6">
          <div className="cursor-pointer mb-12 flex items-center justify-center" onClick={resetForm}>
            <img src="https://upload.wikimedia.org/wikipedia/pt/2/23/Logotipo_Smiles.png" alt="Smiles" className="w-32 brightness-0 invert" />
          </div>
          <nav className="space-y-3">
            <button onClick={() => { setView('OPERATOR'); setAdminAuth(false); }} className={`w-full text-left px-5 py-4 rounded-2xl flex items-center gap-4 font-bold transition-all text-[11px] uppercase tracking-widest ${view === 'OPERATOR' ? 'bg-[#FF671B] text-white' : 'text-gray-400 hover:text-white'}`}>
              <i className="fas fa-file-pen text-base"></i><span>Novo Registro</span>
            </button>
            <button onClick={handleAdminAccess} className={`w-full text-left px-5 py-4 rounded-2xl flex items-center gap-4 font-bold transition-all text-[11px] uppercase tracking-widest ${view === 'ADMIN' ? 'bg-[#FF671B] text-white' : 'text-gray-400 hover:text-white'}`}>
              <i className="fas fa-shield-halved text-base"></i><span>Painel Admin</span>
            </button>
          </nav>
        </div>
      </aside>

      <main className="flex-1 lg:ml-64 min-h-screen flex flex-col">
        <header className="h-16 bg-white border-b px-8 flex items-center justify-between sticky top-0 z-50 shadow-sm">
          <h1 className="text-[11px] font-black text-[#121B33] uppercase tracking-[0.3em] flex items-center gap-4">
            <div className="w-1.5 h-6 bg-[#FF671B] rounded-full"></div>
            {view === 'ADMIN' ? 'Gestão de Fila Admin' : 'Terminal Smiles AI'}
          </h1>
          <button onClick={handleAdminAccess} className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF671B] flex items-center justify-center border border-orange-100">
            <i className={`fas ${view === 'ADMIN' ? 'fa-arrow-left' : 'fa-lock'}`}></i>
          </button>
        </header>

        <div className="p-6 md:p-10 flex-1 flex flex-col items-center">
          <div className="w-full max-w-5xl">
            {view === 'ADMIN' && adminAuth ? (
              <div className="animate-slide space-y-10">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <StatCard label="Crítico" val={stats.critical} color="text-red-600" bg="bg-red-50" icon="fa-fire" />
                  <StatCard label="Alta" val={stats.high} color="text-orange-500" bg="bg-orange-50" icon="fa-bolt" />
                  <StatCard label="Normal" val={stats.normal} color="text-blue-600" bg="bg-blue-50" icon="fa-plane" />
                  <StatCard label="Total" val={registrations.length} color="text-white" bg="bg-[#121B33]" icon="fa-database" dark />
                </div>

                <div className="relative">
                  <i className="fas fa-search absolute left-6 top-1/2 -translate-y-1/2 text-gray-300"></i>
                  <input type="text" placeholder="BUSCAR PNR, TKT OU OPERADOR..." className="w-full pl-14 pr-6 py-5 bg-white border rounded-3xl outline-none focus:ring-4 focus:ring-orange-500/5 font-bold uppercase text-[11px] tracking-widest shadow-sm" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>

                <div className="space-y-4 pb-20">
                  {filteredAndSortedRegistrations.length === 0 ? (
                    <div className="bg-white p-20 rounded-[3rem] text-center border-2 border-dashed border-gray-100">
                      <p className="text-gray-400 font-black uppercase text-[11px]">Nenhum registro pendente</p>
                    </div>
                  ) : (
                    filteredAndSortedRegistrations.map((reg) => {
                      const priority = getPriorityInfo(reg.dataVoo);
                      return (
                        <div key={reg.id} className="bg-white rounded-3xl p-6 border shadow-sm flex flex-col md:flex-row items-center gap-8 relative overflow-hidden">
                          <div className={`absolute left-0 top-0 bottom-0 w-2 ${priority.color}`}></div>
                          <div className="flex-1">
                            <div className="flex flex-wrap items-center gap-3 mb-3">
                              <span className={`text-[9px] font-black uppercase px-3 py-1.5 rounded-lg ${priority.color} text-white`}>{priority.label}</span>
                              <span className="text-[10px] font-black text-[#121B33] bg-gray-50 px-3 py-1.5 rounded-lg border">PNR: {reg.localizador}</span>
                            </div>
                            <h3 className="text-[12px] font-black text-[#121B33] uppercase">Agente: {reg.operador}</h3>
                            <p className="text-[10px] text-gray-400 font-bold">Voo: {reg.dataVoo}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <button onClick={() => resolveTicket(reg.id)} className="w-12 h-12 bg-emerald-50 text-emerald-500 rounded-2xl flex items-center justify-center hover:bg-emerald-500 hover:text-white transition-all"><i className="fas fa-check"></i></button>
                            <button onClick={() => setSelectedTicket(reg)} className="w-12 h-12 bg-gray-50 text-gray-400 rounded-2xl flex items-center justify-center hover:bg-[#121B33] hover:text-white transition-all"><i className="fas fa-eye"></i></button>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </div>
            ) : (
              state !== AppState.SUCCESS ? (
                <div className="animate-slide w-full max-w-4xl mx-auto pb-20">
                  <div className="bg-white rounded-[3rem] p-10 md:p-14 shadow-2xl border relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-2 bg-[#FF671B]"></div>
                    <div className="flex items-center gap-8 mb-14">
                      <div className="w-20 h-20 bg-orange-50 rounded-[2rem] flex items-center justify-center text-[#FF671B] text-4xl shadow-sm border border-orange-100"><i className="fas fa-plane-up"></i></div>
                      <div><h2 className="text-3xl font-black text-[#121B33] uppercase leading-none">Registro Operacional</h2><p className="text-[11px] text-gray-400 font-bold uppercase tracking-[0.3em] mt-3">Sincronização Nuvem & Admin</p></div>
                    </div>
                    <form onSubmit={handleSubmit} className="space-y-12">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <InputField label="Nome do Agente" icon="fa-id-badge" placeholder="Quem está operando?" value={formData.operador} onChange={(v) => setFormData({...formData, operador: v})} required />
                        <DateInputField label="Data do Voo" value={formData.dataVoo} onChange={(v) => setFormData({...formData, dataVoo: v})} required />
                      </div>
                      <MultiSelectField label="Serviços Impactados" options={[{ value: 'FF', label: 'FF', icon: 'fa-star' }, { value: 'ASSENTO', label: 'Assentos', icon: 'fa-couch' }, { value: 'BAGAGEM', label: 'Bagagem', icon: 'fa-suitcase-rolling' }]} selectedValues={formData.tipo} onChange={(vals) => setFormData({...formData, tipo: vals})} required />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <InputField label="TKT / Protocolo" icon="fa-barcode" placeholder="EX: 127242..." value={formData.tkt} onChange={(v) => setFormData({...formData, tkt: v})} required />
                        <InputField label="Localizador (PNR)" icon="fa-passport" placeholder="EX: ABCDEF" value={formData.localizador} onChange={(v) => setFormData({...formData, localizador: v.toUpperCase()})} required />
                      </div>
                      <InputField label="Relato do Atendimento" textarea rows={5} placeholder="Relate o que foi tratado..." value={formData.bio} onChange={(v) => setFormData({...formData, bio: v})} required />
                      <div className="pt-6">
                        <Button type="submit" className="w-full py-9 rounded-[2.5rem] text-2xl font-black tracking-[0.5em]" isLoading={state === AppState.SUBMITTING}>{state === AppState.SUBMITTING ? 'SINCRONIZANDO...' : 'TRANSMITIR DADOS'}</Button>
                      </div>
                    </form>
                  </div>
                </div>
              ) : (
                <div className="animate-slide w-full max-w-3xl mx-auto pb-20">
                  <div className="bg-white rounded-[4rem] p-16 shadow-2xl border text-center relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500"></div>
                    <div className="w-24 h-24 bg-emerald-50 text-emerald-500 rounded-[3rem] flex items-center justify-center text-4xl mx-auto mb-10"><i className="fas fa-cloud-upload-alt"></i></div>
                    <h2 className="text-4xl font-black text-[#121B33] uppercase mb-4">Transmitido!</h2>
                    <p className="text-gray-400 font-bold uppercase tracking-widest text-[12px] mb-12">Dados salvos na Planilha e no Admin.</p>
                    <div className="bg-gray-50 p-10 rounded-[3rem] text-left border mb-12">
                      <p className="text-[10px] font-black text-[#FF671B] uppercase mb-4">Súmula Técnica</p>
                      <p className="text-sm font-bold text-[#121B33] italic leading-relaxed">"{aiResult?.summary}"</p>
                    </div>
                    <Button onClick={resetForm} className="w-full py-7 rounded-[2rem]">NOVO REGISTRO</Button>
                  </div>
                </div>
              )
            )}
          </div>
        </div>
      </main>

      {selectedTicket && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#121B33]/95 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-3xl rounded-[3rem] shadow-2xl animate-slide relative overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-10 pb-6 flex justify-between items-start border-b">
              <div><h3 className="text-2xl font-black text-[#121B33] uppercase">Detalhes Técnicos</h3><p className="text-[11px] text-gray-400 font-bold uppercase mt-2">UUID: {selectedTicket.id}</p></div>
              <button onClick={() => setSelectedTicket(null)} className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-400 hover:text-red-500"><i className="fas fa-times text-xl"></i></button>
            </div>
            <div className="p-10 overflow-y-auto space-y-10">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <InfoBox label="PNR" val={selectedTicket.localizador} highlight />
                <InfoBox label="TKT" val={selectedTicket.tkt} />
                <InfoBox label="VOO" val={selectedTicket.dataVoo} />
                <InfoBox label="AGENTE" val={selectedTicket.operador} />
              </div>
              <div>
                <p className="text-[11px] font-black text-[#121B33] uppercase mb-4 tracking-widest">Relato Operacional</p>
                <div className="p-8 bg-gray-50 rounded-[2.5rem] border text-sm font-bold text-[#121B33] leading-relaxed italic shadow-inner">"{selectedTicket.bio}"</div>
              </div>
            </div>
            <div className="p-10 pt-4 flex gap-6 bg-gray-50/50 border-t">
              <Button onClick={() => resolveTicket(selectedTicket.id)} variant="secondary" className="flex-1 py-7 rounded-[2rem] text-xl font-black">RESOLVIDO</Button>
              <button onClick={() => setSelectedTicket(null)} className="flex-1 py-7 rounded-[2rem] border-4 border-gray-100 font-black text-[#121B33] uppercase text-[13px] tracking-widest">VOLTAR</button>
            </div>
          </div>
        </div>
      )}

      {showPassModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#121B33]/90 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-sm rounded-[3rem] p-12 shadow-2xl animate-slide text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-[#FF671B]"></div>
            <button onClick={() => setShowPassModal(false)} className="absolute top-8 right-8 text-gray-400"><i className="fas fa-times"></i></button>
            <div className="w-20 h-20 bg-orange-50 text-[#FF671B] rounded-[2rem] flex items-center justify-center text-3xl mx-auto mb-8 shadow-inner"><i className="fas fa-user-lock"></i></div>
            <h3 className="text-2xl font-black text-[#121B33] uppercase mb-10">Acesso Admin</h3>
            <input type="password" autoFocus className="w-full px-6 py-5 bg-gray-50 border rounded-2xl text-center font-black tracking-[0.8em] text-xl outline-none mb-8 focus:ring-4 focus:ring-orange-500/10" placeholder="SENHA" value={passInput} onChange={(e) => setPassInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && verifyPassword()} />
            <Button onClick={verifyPassword} className="w-full py-5 rounded-2xl font-black">DESBLOQUEAR</Button>
          </div>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ label, val, color, bg, icon, dark }: any) => (
  <div className={`p-6 rounded-[2rem] shadow-sm flex items-center gap-4 border ${bg}`}>
    <div className={`w-12 h-12 ${dark ? 'bg-white/10' : 'bg-white'} rounded-2xl flex items-center justify-center ${color}`}><i className={`fas ${icon}`}></i></div>
    <div><p className={`text-[9px] font-black ${dark ? 'text-white/40' : 'text-gray-400'} uppercase`}>{label}</p><p className={`text-2xl font-black ${color}`}>{val}</p></div>
  </div>
);

const InfoBox = ({ label, val, highlight }: any) => (
  <div className={`p-5 rounded-[1.5rem] border ${highlight ? 'bg-orange-50 border-orange-100 text-[#FF671B]' : 'bg-gray-50 border-gray-100 text-[#121B33]'}`}>
    <p className={`text-[9px] font-black uppercase mb-2 ${highlight ? 'text-orange-400' : 'text-gray-400'}`}>{label}</p>
    <p className="text-base font-black truncate">{val}</p>
  </div>
);

export default App;
